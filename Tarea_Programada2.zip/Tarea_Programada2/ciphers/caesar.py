# Clase que implementa el Cifrado César
class CaesarCipher:
    def __init__(self, shift: int):
        # Guardamos el desplazamiento (mod 26 para que no se pase del alfabeto)
        self.shift = shift % 26
        # Definimos el alfabeto en minúsculas
        self.alphabet = "abcdefghijklmnopqrstuvwxyz"

    def _transform(self, text: str, shift: int) -> str:
        """
        Método interno que aplica el desplazamiento (positivo o negativo).
        Sirve tanto para encriptar como para desencriptar.
        """
        result = []
        for char in text.lower():  # Convertimos todo a minúsculas
            if char in self.alphabet:
                # Calculamos la nueva posición con desplazamiento circular
                idx = (self.alphabet.index(char) + shift) % 26
                result.append(self.alphabet[idx])
            else:
                # Si no es letra (espacio, número, etc.), lo dejamos igual
                result.append(char)
        return "".join(result)

    def encrypt(self, text: str) -> str:
        """Encripta el texto aplicando el desplazamiento positivo."""
        return self._transform(text, self.shift)

    def decrypt(self, text: str) -> str:
        """Desencripta el texto aplicando el desplazamiento negativo."""
        return self._transform(text, -self.shift)