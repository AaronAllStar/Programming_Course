# Clase que implementa el Cifrado Vigenère
class VigenereCipher:
    def __init__(self, keyword: str):
        # Validamos que la palabra clave no tenga letras repetidas
        if len(set(keyword.lower())) != len(keyword):
            raise ValueError("La palabra clave no debe repetir letras")
        self.keyword = keyword.lower()
        self.alphabet = "abcdefghijklmnopqrstuvwxyz"

    def _extend_keyword(self, text: str) -> str:
        """
        Extiende la palabra clave para que tenga la misma longitud
        que el texto a encriptar/desencriptar.
        """
        keyword_extended = ""
        keyword_index = 0
        for char in text.lower():
            if char in self.alphabet:
                # Repetimos la clave letra por letra
                keyword_extended += self.keyword[keyword_index % len(self.keyword)]
                keyword_index += 1
            else:
                # Si no es letra, dejamos el mismo carácter
                keyword_extended += char
        return keyword_extended

    def encrypt(self, text: str) -> str:
        """Encripta el texto usando la clave."""
        result = []
        extended = self._extend_keyword(text)
        for t, k in zip(text.lower(), extended):
            if t in self.alphabet:
                # El desplazamiento depende de la letra de la clave
                shift = self.alphabet.index(k)
                idx = (self.alphabet.index(t) + shift) % 26
                result.append(self.alphabet[idx])
            else:
                result.append(t)
        return "".join(result)

    def decrypt(self, text: str) -> str:
        """Desencripta el texto usando la clave."""
        result = []
        extended = self._extend_keyword(text)
        for t, k in zip(text.lower(), extended):
            if t in self.alphabet:
                shift = self.alphabet.index(k)
                idx = (self.alphabet.index(t) - shift) % 26
                result.append(self.alphabet[idx])
            else:
                result.append(t)
        return "".join(result)