def print_welcome():
    print("=== Bienvenido al Programa de Encriptación ===")
    print("Puede salir en cualquier momento dejando el texto vacío.\n")

def get_text_from_user():
    return input("Ingrese el texto (o presione Enter para salir): ").strip().lower()

def get_algorithm_from_user():
    while True:
        alg = input("Seleccione algoritmo (cesar/vigenere): ").strip().lower()
        if alg in ["cesar", "vigenere"]:
            return alg
        print("Opción inválida. Intente de nuevo.")

def get_operation_from_user():
    while True:
        op = input("¿Desea encriptar o desencriptar? (encriptar/desencriptar): ").strip().lower()
        if op in ["encriptar", "desencriptar"]:
            return op
        print("Opción inválida. Intente de nuevo.")

def get_shift_from_user():
    while True:
        try:
            return int(input("Ingrese el desplazamiento (número entero): "))
        except ValueError:
            print("Debe ingresar un número válido.")

def get_key_from_user():
    return input("Ingrese la palabra clave (sin letras repetidas): ").strip().lower()

def print_result(original, result, algorithm, operation):
    print("\n=== RESULTADO ===")
    print(f"Algoritmo: {algorithm}")
    print(f"Operación: {operation}")
    print(f"Texto original: {original}")
    print(f"Texto resultante: {result}\n")

def ask_continue():
    resp = input("¿Desea continuar? (s/n): ").strip().lower()
    return resp == "s"

def print_goodbye():
    print("\nGracias por usar el programa. ¡Hasta luego!")