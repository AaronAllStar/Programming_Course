"""Entrada principal del programa.

Este módulo orquesta la interacción entre la UI (`ui.py`) y los cifrados
definidos en el paquete `ciphers`.
"""

from ciphers import CaesarCipher, VigenereCipher

# Cargador robusto para el módulo `ui`.
# Problema: si existe un paquete/namespace `ui/` sin __init__.py,
# `import ui` puede devolver un namespace package sin atributos.
# Intentamos:
# 1. Importar `ui` normalmente y usarlo si expone `print_welcome`.
# 2. Si no, buscar archivos `ui.py` o `ui/ui.py` en el mismo directorio
#    del proyecto y cargar el módulo desde el archivo (por ruta).
import importlib
import importlib.util
import os
import sys


def _load_ui_module():
    # 1) Intento de importación directa
    try:
        import ui as _ui
        if hasattr(_ui, 'print_welcome'):
            return _ui
    except Exception:
        pass

    # 2) Intentar localizar ui.py en el directorio del proyecto
    base = os.path.dirname(__file__)
    candidates = [os.path.join(base, 'ui.py'), os.path.join(base, 'ui', 'ui.py')]
    for path in candidates:
        if os.path.isfile(path):
            spec = importlib.util.spec_from_file_location('ui', path)
            module = importlib.util.module_from_spec(spec)
            # Registrar el módulo en sys.modules para que importaciones posteriores
            # lo encuentren como 'ui'.
            sys.modules['ui'] = module
            spec.loader.exec_module(module)
            return module

    raise ImportError("No se pudo cargar un módulo 'ui' válido. Buscado: ui.py, ui/ui.py")


# Cargar y asignar el módulo `ui` usable
ui = _load_ui_module()


class Menu:
    """Menu principal que dirige el flujo del programa.

    Uso:
        Menu().run()
    """

    def run(self):
        """Ejecuta el bucle principal de interacción con el usuario.

        - Pide texto, algoritmo y operación.
        - Construye el cifrador correspondiente y muestra el resultado.
        - Permite repetir operaciones hasta que el usuario decida salir.
        """
        ui.print_welcome()

        while True:
            text = ui.get_text_from_user()
            # Si el usuario simplemente presiona Enter sin texto, salimos
            if text == "":
                break

            algorithm = ui.get_algorithm_from_user()
            operation = ui.get_operation_from_user()

            # Crear el objeto cifrador según el algoritmo seleccionado
            cipher = None
            if algorithm == "cesar":
                shift = ui.get_shift_from_user()
                cipher = CaesarCipher(shift)
            elif algorithm == "vigenere":
                # `get_key_from_user` ya valida y normaliza la clave
                keyword = ui.get_key_from_user()
                cipher = VigenereCipher(keyword)
            else:
                print("ERROR: Algoritmo no reconocido.")
                continue

            # Ejecutar la operación solicitada
            if operation == "encriptar":
                result = cipher.encrypt(text)
            else:
                result = cipher.decrypt(text)

            ui.print_result(text, result, algorithm, operation)

            if not ui.ask_continue():
                break

        ui.print_goodbye()


if __name__ == "__main__":
    Menu().run()
