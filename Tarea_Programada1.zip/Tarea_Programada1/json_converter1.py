"""
Convertidor CSV a JSON - Solo Python Standard Library
Uso: python json_converter.py archivo.csv
"""

import json
import csv
import sys


class JSONConverter:
    """Clase para convertir archivos CSV a formato JSON"""

    def __init__(self):
        pass

    def read_csv_and_convert(self, csv_filename, output_filename):
        """
        Lee un archivo CSV y lo convierte directamente a JSON
        
        Args:
            csv_filename (str): Nombre del archivo CSV a leer
            output_filename (str): Nombre del archivo JSON de salida
        """
        print(f"Leyendo archivo CSV: {csv_filename}")
        
        # Leer el archivo CSV
        data = self._read_csv_file(csv_filename)
        
        if not data:
            print("Error: No se pudieron leer datos del archivo CSV")
            return False
        
        print(f"Datos leídos: {len(data)-1} registros, {len(data[0])} columnas")
        
        # Convertir a JSON
        self.convert_to_json(data, output_filename)
        return True

    def _read_csv_file(self, csv_filename):
        """Lee un archivo CSV y devuelve los datos como lista de listas"""
        try:
            datos = []
            
            with open(csv_filename, 'r', encoding='utf-8', newline='') as archivo:
                # Detectar el delimitador automáticamente
                muestra = archivo.read(1024)
                archivo.seek(0)
                
                sniffer = csv.Sniffer()
                delimitador = sniffer.sniff(muestra).delimiter
                print(f"   Delimitador detectado: '{delimitador}'")
                
                # Leer el CSV
                lector = csv.reader(archivo, delimiter=delimitador)
                
                for fila in lector:
                    fila_limpia = [campo.strip() for campo in fila]
                    datos.append(fila_limpia)
            
            return datos
            
        except FileNotFoundError:
            print(f"Error: No se encontró el archivo '{csv_filename}'")
            return None
        except Exception as e:
            print(f"Error al leer el archivo CSV: {e}")
            return None

    def convert_to_json(self, data, output_filename):
        """Convierte los datos a formato JSON y los guarda en un archivo"""
        if not data or len(data) < 1:
            raise ValueError("Los datos están vacíos")

        headers = data[0]
        rows = data[1:]

        # Convertir datos a lista de diccionarios
        json_data = []

        for row_index, row in enumerate(rows):
            record = {}
            
            for header, value in zip(headers, row):
                converted_value = self._convert_value(value)
                record[header] = converted_value

            json_data.append(record)

        # Crear estructura JSON final
        output_data = {
            "dataset": {
                "metadata": {
                    "total_records": len(json_data),
                    "fields": headers,
                    "generated_by": "CSV to JSON Converter"
                },
                "records": json_data
            }
        }

        # Guardar en archivo con formato bonito
        with open(output_filename, 'w', encoding='utf-8') as f:
            json.dump(output_data, f, indent=2, ensure_ascii=False)

        print(f"Archivo JSON guardado como: {output_filename}")
        print(f"Registros procesados: {len(json_data)}")

    def _convert_value(self, value):
        """Convierte un valor string al tipo apropiado (número, boolean, etc.)"""
        if not value or value.strip() == "":
            return ""

        value = value.strip()

        # Intentar convertir a boolean
        if value.lower() in ['true', 'verdadero', 'si', 'sí']:
            return True
        elif value.lower() in ['false', 'falso', 'no']:
            return False

        # Intentar convertir a entero
        try:
            if '.' not in value and ',' not in value:
                return int(value)
        except ValueError:
            pass

        # Intentar convertir a float
        try:
            normalized_value = value.replace(',', '.')
            return float(normalized_value)
        except ValueError:
            pass

        # Si no se puede convertir, mantener como string
        return value

    def save_simple_json(self, data, output_filename):
        """Guarda datos en formato JSON simple (sin metadata)"""
        if not data or len(data) < 1:
            return []

        headers = data[0]
        rows = data[1:]

        json_data = []
        for row in rows:
            record = {}
            for header, value in zip(headers, row):
                record[header] = self._convert_value(value)
            json_data.append(record)

        with open(output_filename, 'w', encoding='utf-8') as f:
            json.dump(json_data, f, indent=2, ensure_ascii=False)
        
        print(f" JSON simple guardado como: {output_filename}")


# Uso desde línea de comandos
if __name__ == "__main__":
    print("=" * 50)
    print("CONVERTIDOR CSV A JSON")
    print("=" * 50)
    
    if len(sys.argv) > 1:
        csv_file = sys.argv[1]
        json_file = csv_file.replace('.csv', '.json')
        
        converter = JSONConverter()
        converter.read_csv_and_convert(csv_file, json_file)
    else:
        print("\nUSO:")
        print("  python json_converter.py archivo.csv")
        print("\nEJEMPLOS:")
        print("  python json_converter.py datos.csv")
        print("  python json_converter.py estudiantes.csv")
