
import csv

# Crear archivo CSV de ejemplo para testing
sample_data = [
    ['nombre', 'apellido1', 'apellido2', 'direccion', 'edad', 'activo'],
    ['Mario', 'Aguero', 'Lopez', 'San Jose', '38', 'true'],
    ['Ana', 'Rodriguez', 'Martinez', 'Cartago', '25', 'false'],
    ['Carlos', 'Vargas', 'Jimenez', 'Heredia', '42', 'true'],
    ['Maria', 'Castro', 'Gonzalez', 'Alajuela', '35', 'true'],
    ['Jose', 'Morales', 'Fernandez', 'Puntarenas', '29', 'false']
]

# Guardar archivo CSV de ejemplo
with open('ejemplo.csv', 'w', newline='', encoding='utf-8') as f:
    writer = csv.writer(f)
    writer.writerows(sample_data)

print("Archivo ejemplo.csv creado para testing")

# También crear un README con instrucciones
readme_content = """
# Convertidor de Formatos de Datos
## Tarea Programada 1 - Universidad Lead
### Profesor: Mario Agüero

### Descripción
Este programa convierte archivos CSV a diferentes formatos:
- XML (Extensible Markup Language)
- JSON (JavaScript Object Notation)  
- TRAMA (Formato de bytes para transmisión)

### Requisitos
- Python 3.9 o superior
- Solo usa la librería estándar de Python (no requiere pip install)

### Estructura del Proyecto
```
├── main.py              # Programa principal
├── data_processor.py    # Procesador de archivos CSV
├── xml_converter.py     # Convertidor a XML
├── json_converter.py    # Convertidor a JSON
├── frame_converter.py   # Convertidor a tramas de bytes
├── file_utils.py        # Utilidades para manejo de archivos
├── ejemplo.csv          # Archivo CSV de ejemplo
└── README.md            # Este archivo
```

### Uso
```bash
python main.py <archivo.csv>
```

### Ejemplos
```bash
# Convertir archivo de ejemplo
python main.py ejemplo.csv

# Convertir cualquier archivo CSV
python main.py datos.csv
python main.py empleados.csv
```

### Formatos de Salida

#### XML
- Extensión: `.xml`
- Estructura jerárquica con etiquetas
- Validable en: https://www.xmlvalidation.com/

#### JSON  
- Extensión: `.json`
- Formato de intercambio de datos moderno
- Validable en: https://jsonviewer.stack.hu/

#### TRAMA
- Extensión: `.dat`
- Formato binario para transmisión
- Estructura: [STX][LEN][DATA][CRC][ETX]
- STX = 0x02 (inicio)
- LEN = Longitud de datos
- DATA = Información en ASCII-HEX  
- CRC = Checksum (suma módulo 256)
- ETX = 0x03 (fin)
- Separador: '|' (pipe)

### Características
- Interfaz interactiva paso a paso
- Validación de archivos y datos
- Selección de columnas específicas
- Respaldo automático de archivos existentes
- Mensajes informativos y de error detallados
- Solo usa Python Standard Library

### Validaciones Implementadas
- Verificación de argumentos de línea de comandos
- Validación de existencia y permisos de archivos
- Verificación de formato CSV válido
- Validación de estructura de datos
- Verificación de permisos de escritura

### Ejemplo de Ejecución
```
$ python main.py ejemplo.csv

============================================================
    CONVERTIDOR DE FORMATOS DE DATOS
    Universidad Lead - Tarea Programada 1
    Profesor: Mario Agüero
============================================================

Este programa convierte archivos CSV a:
  • XML - Formato de marcado extensible
  • JSON - Notación de objetos JavaScript
  • TRAMA - Formato de bytes para transmisión

Solo utiliza la librería estándar de Python
------------------------------------------------------------

Archivo válido: ejemplo.csv

==================================================
SELECCIÓN DE FORMATO DE SALIDA
==================================================

Seleccione formato (xml/json/trama): json

==================================================
SELECCIÓN DE COLUMNAS  
==================================================

Columnas disponibles en el archivo CSV:
----------------------------------------
   1. nombre
   2. apellido1  
   3. apellido2
   4. direccion
   5. edad
   6. activo

¿Desea usar TODAS las columnas? (s/n): s

==================================================
PROCESANDO CONVERSIÓN
==================================================

Generando archivo JSON...
Archivo de salida: ejemplo.json

CONVERSIÓN COMPLETADA EXITOSAMENTE
```

### Autor
Desarrollado para Universidad Lead - III Cuatrimestre 2025

### Notas Técnicas
- Codificación: UTF-8
- Separador CSV: Detección automática
- Manejo de errores: Comprensivo con mensajes informativos
- Arquitectura: Modular y orientada a objetos
- Documentación: Extensiva con docstrings y comentarios
"""

with open('README.md', 'w', encoding='utf-8') as f:
    f.write(readme_content)

print("Archivo README.md creado con instrucciones completas")
