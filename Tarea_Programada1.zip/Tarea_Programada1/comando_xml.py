from xml_converter import XMLConverter

converter = XMLConverter()
converter.read_csv_and_convert('ejemplo.csv', 'ejemplo.xml')
