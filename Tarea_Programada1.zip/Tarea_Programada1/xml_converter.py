"""
Convertidor CSV a XML - Solo Python Standard Library
Uso: python xml_converter.py archivo.csv
"""

import xml.etree.ElementTree as ET
from xml.dom import minidom
import csv
import sys


class XMLConverter:
    """Clase para convertir archivos CSV a formato XML"""

    def __init__(self):
        pass

    def read_csv_and_convert(self, csv_filename, output_filename):
        """
        Lee un archivo CSV y lo convierte directamente a XML
        
        Args:
            csv_filename (str): Nombre del archivo CSV a leer
            output_filename (str): Nombre del archivo XML de salida
        """
        print(f"Leyendo archivo CSV: {csv_filename}")
        
        # Leer el archivo CSV
        data = self._read_csv_file(csv_filename)
        
        if not data:
            print("Error: No se pudieron leer datos del archivo CSV")
            return False
        
        print(f"Datos leídos: {len(data)-1} registros, {len(data[0])} columnas")
        
        # Convertir a XML
        self.convert_to_xml(data, output_filename)
        return True

    def _read_csv_file(self, csv_filename):
        """Lee un archivo CSV y devuelve los datos como lista de listas"""
        try:
            datos = []
            
            with open(csv_filename, 'r', encoding='utf-8', newline='') as archivo:
                # Detectar el delimitador automáticamente
                muestra = archivo.read(1024)
                archivo.seek(0)
                
                sniffer = csv.Sniffer()
                delimitador = sniffer.sniff(muestra).delimiter
                print(f"   Delimitador detectado: '{delimitador}'")
                
                # Leer el CSV
                lector = csv.reader(archivo, delimiter=delimitador)
                
                for fila in lector:
                    fila_limpia = [campo.strip() for campo in fila]
                    datos.append(fila_limpia)
            
            return datos
            
        except FileNotFoundError:
            print(f"Error: No se encontró el archivo '{csv_filename}'")
            return None
        except Exception as e:
            print(f"Error al leer el archivo CSV: {e}")
            return None

    def convert_to_xml(self, data, output_filename):
        """
        Convierte los datos a formato XML y los guarda en un archivo

        Args:
            data (list): Lista de listas con los datos (primera fila son headers)
            output_filename (str): Nombre del archivo de salida
        """
        if not data or len(data) < 1:
            raise ValueError("Los datos están vacíos")

        headers = data[0]
        rows = data[1:]

        # Crear el elemento raíz
        root = ET.Element("dataset")

        # Procesar cada fila de datos
        for row_index, row in enumerate(rows):
            # Crear elemento para cada registro
            record = ET.SubElement(root, "record")
            record.set("id", str(row_index + 1))

            # Agregar cada campo como subelemento
            for header, value in zip(headers, row):
                # Limpiar nombre de campo para XML válido
                field_name = self._clean_xml_tag(header)
                field_element = ET.SubElement(record, field_name)
                field_element.text = str(value) if value else ""

        # Convertir a string con formato bonito
        xml_string = ET.tostring(root, encoding='unicode')

        # Formatear con minidom para mejor presentación
        dom = minidom.parseString(xml_string)
        pretty_xml = dom.toprettyxml(indent="  ")

        # Remover líneas vacías extra
        lines = [line for line in pretty_xml.split('\n') if line.strip()]
        formatted_xml = '\n'.join(lines)

        # Guardar en archivo
        with open(output_filename, 'w', encoding='utf-8') as f:
            f.write(formatted_xml)

        print(f"Archivo XML guardado como: {output_filename}")
        print(f"Registros procesados: {len(rows)}")

    def _clean_xml_tag(self, tag_name):
        """
        Limpia el nombre del tag para que sea válido en XML

        Args:
            tag_name (str): Nombre original del tag

        Returns:
            str: Nombre del tag limpio y válido para XML
        """
        # Reemplazar espacios con guiones bajos
        clean_tag = tag_name.strip().replace(' ', '_')

        # Remover caracteres no válidos y mantener solo letras, números, guiones y guiones bajos
        valid_chars = []
        for i, char in enumerate(clean_tag):
            if char.isalnum() or char in ['-', '_']:
                valid_chars.append(char)
            elif char in ['.', ',', '(', ')', '[', ']']:
                valid_chars.append('_')

        clean_tag = ''.join(valid_chars)

        # Asegurar que comience con una letra
        if clean_tag and not clean_tag[0].isalpha():
            clean_tag = 'field_' + clean_tag

        # Si está vacío, usar nombre por defecto
        if not clean_tag:
            clean_tag = 'field'

        return clean_tag

    def validate_xml(self, xml_string):
        """
        Valida si el XML está bien formado

        Args:
            xml_string (str): Cadena XML a validar

        Returns:
            bool: True si el XML es válido
        """
        try:
            ET.fromstring(xml_string)
            return True
        except ET.ParseError:
            return False


# Uso desde línea de comandos
if __name__ == "__main__":
    print("=" * 50)
    print("CONVERTIDOR CSV A XML")
    print("=" * 50)
    
    if len(sys.argv) > 1:
        csv_file = sys.argv[1]
        xml_file = csv_file.replace('.csv', '.xml')
        
        converter = XMLConverter()
        converter.read_csv_and_convert(csv_file, xml_file)
    else:
        print("\nUSO:")
        print("  python xml_converter.py archivo.csv")
        print("\nEJEMPLOS:")
        print("  python xml_converter.py datos.csv")
        print("  python xml_converter.py estudiantes.csv")
