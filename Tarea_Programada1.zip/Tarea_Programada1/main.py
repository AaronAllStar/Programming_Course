
#!/usr/bin/env python3
"""
Tarea Programada 1 - Universidad Lead
Programa para convertir archivos CSV a XML, JSON o Tramas de bytes
Profesor: Mario Agüero
Solo usa Python Standard Library
"""

import sys
import os
from data_processor import DataProcessor
from xml_converter import XMLConverter
from json_converter import JSONConverter

def main():
    # Verificar argumentos de línea de comandos
    if len(sys.argv) != 2:
        print("Uso: python main.py <archivo.csv>")
        sys.exit(1)

    csv_filename = sys.argv[1]

    # Verificar si el archivo existe
    if not os.path.exists(csv_filename):
        print(f"Error: El archivo '{csv_filename}' no existe.")
        sys.exit(1)

    # Verificar que sea un archivo CSV
    if not csv_filename.lower().endswith('.csv'):
        print("Error: El archivo debe tener extensión .csv")
        sys.exit(1)

    try:
        # Leer y procesar el archivo CSV
        processor = DataProcessor()
        data = processor.read_csv(csv_filename)

        if not data:
            print("Error: No se pudieron leer datos del archivo CSV.")
            sys.exit(1)

        # Mostrar formatos disponibles
        print("\nFormatos de salida disponibles:")
        print("1. xml - Formato XML")
        print("2. json - Formato JSON") 
        print("3. trama - Formato de trama de bytes")

        # Solicitar formato de salida
        while True:
            format_choice = input("\nSeleccione el formato de salida (xml/json/trama): ").lower().strip()
            if format_choice in ['xml', 'json', 'trama']:
                break
            print("Opción inválida. Por favor ingrese: xml, json o trama")

        # Mostrar columnas disponibles
        headers = data[0]
        print("\nColumnas disponibles:")
        for i, header in enumerate(headers, 1):
            print(f"{i}- {header}")

        # Solicitar selección de columnas
        while True:
            column_choice = input("\n¿Desea usar todas las columnas? (s/n): ").lower().strip()
            if column_choice in ['s', 'n', 'si', 'no']:
                break
            print("Por favor ingrese 's' para sí o 'n' para no")

        selected_columns = None
        if column_choice in ['n', 'no']:
            while True:
                try:
                    columns_input = input("Ingrese los números de las columnas separados por coma (ej: 1,3,5): ")
                    column_numbers = [int(x.strip()) for x in columns_input.split(',')]

                    # Validar números de columna
                    if all(1 <= num <= len(headers) for num in column_numbers):
                        selected_columns = [num - 1 for num in column_numbers]  # Convertir a índices base 0
                        break
                    else:
                        print(f"Error: Los números deben estar entre 1 y {len(headers)}")
                except ValueError:
                    print("Error: Ingrese solo números separados por coma")

        # Filtrar datos según columnas seleccionadas
        if selected_columns:
            data = processor.filter_columns(data, selected_columns)

        # Generar nombre del archivo de salida
        base_name = os.path.splitext(csv_filename)[0]

        # Convertir según el formato seleccionado
        if format_choice == 'xml':
            converter = XMLConverter()
            output_filename = f"{base_name}.xml"
            converter.convert_to_xml(data, output_filename)

        elif format_choice == 'json':
            converter = JSONConverter()
            output_filename = f"{base_name}.json"
            converter.convert_to_json(data, output_filename)

        elif format_choice == 'trama':
            converter = FrameConverter()
            output_filename = f"{base_name}.dat"
            converter.convert_to_frame(data, output_filename)

        print(f"\nArchivo convertido exitosamente: {output_filename}")

    except Exception as e:
        print(f"Error durante la conversión: {e}")
        sys.exit(1)


if __name__ == "__main__":
    main()
