
"""
Módulo para procesar archivos CSV
Solo usa Python Standard Library
"""

import csv
import os


class DataProcessor:
    """Clase para procesar datos de archivos CSV"""

    def __init__(self):
        pass

    def read_csv(self, filename):
        """
        Lee un archivo CSV y retorna los datos como lista de listas

        Args:
            filename (str): Nombre del archivo CSV

        Returns:
            list: Lista de listas con los datos del CSV, incluyendo header
        """
        try:
            data = []
            with open(filename, 'r', encoding='utf-8', newline='') as file:
                # Detectar el delimitador automáticamente
                sample = file.read(1024)
                file.seek(0)
                sniffer = csv.Sniffer()
                delimiter = sniffer.sniff(sample).delimiter

                reader = csv.reader(file, delimiter=delimiter)
                for row in reader:
                    # Limpiar espacios en blanco de cada campo
                    clean_row = [field.strip() for field in row]
                    data.append(clean_row)

            return data

        except Exception as e:
            print(f"Error al leer el archivo CSV: {e}")
            return None

    def filter_columns(self, data, column_indices):
        """
        Filtra las columnas especificadas de los datos

        Args:
            data (list): Lista de listas con los datos
            column_indices (list): Lista de índices de columnas a mantener

        Returns:
            list: Datos filtrados con solo las columnas seleccionadas
        """
        if not data:
            return []

        filtered_data = []
        for row in data:
            filtered_row = []
            for index in column_indices:
                if index < len(row):
                    filtered_row.append(row[index])
                else:
                    filtered_row.append("")  # Campo vacío si el índice no existe
            filtered_data.append(filtered_row)

        return filtered_data

    def validate_data(self, data):
        """
        Valida que los datos sean consistentes

        Args:
            data (list): Lista de listas con los datos

        Returns:
            bool: True si los datos son válidos
        """
        if not data or len(data) < 2:  # Al menos header + 1 fila de datos
            return False

        # Verificar que todas las filas tengan el mismo número de columnas que el header
        header_length = len(data[0])
        for i, row in enumerate(data[1:], 1):
            if len(row) != header_length:
                print(f"Advertencia: La fila {i} tiene {len(row)} columnas, esperadas {header_length}")

        return True
