"""
Convertidor CSV a Tramas de Bytes - Solo Python Standard Library
Formato: [STX][LEN][DATA][CRC][ETX]
Uso: python frame_converter.py archivo.csv
"""

import csv
import sys


class FrameConverter:
    """
    Clase para convertir archivos CSV a formato de trama de bytes
    
    Estructura de la trama:
    - STX (0x02): Byte de inicio de trama
    - LEN: Longitud del campo de datos en bytes (1 byte)
    - DATA: Información codificada en ASCII con separador '|'
    - CRC: Checksum (suma de bytes módulo 256)
    - ETX (0x03): Byte de fin de trama
    """
    
    def __init__(self):
        """Inicializa el convertidor con valores por defecto"""
        self.STX = 0x02  # Start of Text - Inicio de trama
        self.ETX = 0x03  # End of Text - Fin de trama
        self.SEPARATOR = '|'  # Separador entre campos

    def read_csv_and_convert(self, csv_filename, output_filename):
        """
        Lee un archivo CSV y lo convierte directamente a tramas de bytes
        
        Args:
            csv_filename (str): Nombre del archivo CSV a leer
            output_filename (str): Nombre del archivo de salida
        """
        print(f"Leyendo archivo CSV: {csv_filename}")
        
        # Leer el archivo CSV
        data = self._read_csv_file(csv_filename)
        
        if not data:
            print("Error: No se pudieron leer datos del archivo CSV")
            return False
        
        print(f"Datos leídos: {len(data)-1} registros, {len(data[0])} columnas")
        
        # Convertir a tramas
        self.convert_to_frame(data, output_filename)
        return True

    def _read_csv_file(self, csv_filename):
        """Lee un archivo CSV y devuelve los datos como lista de listas"""
        try:
            datos = []
            
            with open(csv_filename, 'r', encoding='utf-8', newline='') as archivo:
                # Detectar el delimitador automáticamente
                muestra = archivo.read(1024)
                archivo.seek(0)
                
                sniffer = csv.Sniffer()
                delimitador = sniffer.sniff(muestra).delimiter
                print(f"   Delimitador detectado: '{delimitador}'")
                
                # Leer el CSV
                lector = csv.reader(archivo, delimiter=delimitador)
                
                for fila in lector:
                    fila_limpia = [campo.strip() for campo in fila]
                    datos.append(fila_limpia)
            
            return datos
            
        except FileNotFoundError:
            print(f"Error: No se encontró el archivo '{csv_filename}'")
            return None
        except Exception as e:
            print(f"Error al leer el archivo CSV: {e}")
            return None

    def convert_to_frame(self, data, output_filename):
        """
        Convierte los datos a formato de trama de bytes y los guarda
        
        Args:
            data (list): Lista de listas con los datos (primera fila son headers)
            output_filename (str): Nombre del archivo de salida
        """
        if not data or len(data) < 1:
            raise ValueError("Los datos están vacíos")
        
        headers = data[0]  # Primera fila contiene los encabezados
        rows = data[1:]    # Resto de filas contienen los datos
        
        # Lista para almacenar todas las tramas generadas
        all_frames = []
        
        print("\nCONVIRTIENDO A FORMATO DE TRAMA...")
        print(f"   Formato: [STX][LEN][DATA][CRC][ETX]")
        print(f"   STX = 0x{self.STX:02X}, ETX = 0x{self.ETX:02X}")
        print(f"   Separador = '{self.SEPARATOR}'")
        print("-" * 50)
        
        # Procesar cada fila de datos
        for row_index, row in enumerate(rows, 1):
            print(f"\n   Procesando registro {row_index}:")
            
            # PASO 1: Concatenar campos con separador
            data_string = self.SEPARATOR.join([str(field) if field else "" for field in row])
            print(f"     Datos: {data_string}")
            
            # PASO 2: Convertir string a bytes ASCII
            ascii_bytes = data_string.encode('ascii', errors='ignore')
            
            # PASO 3: Calcular longitud de los datos
            data_length = len(ascii_bytes)
            if data_length > 255:
                print(f"Datos muy largos ({data_length} bytes), truncando a 255")
                ascii_bytes = ascii_bytes[:255]
                data_length = 255
            
            # PASO 4: Calcular checksum (suma módulo 256)
            checksum = sum(ascii_bytes) % 256
            print(f"Longitud: {data_length} bytes (0x{data_length:02X})")
            print(f"Checksum: {checksum} (0x{checksum:02X})")
            
            # PASO 5: Construir la trama completa
            frame = bytearray()
            frame.append(self.STX)         # Inicio
            frame.append(data_length)      # Longitud
            frame.extend(ascii_bytes)      # Datos
            frame.append(checksum)         # Checksum
            frame.append(self.ETX)         # Final
            
            all_frames.append(bytes(frame))
            
            # Mostrar la trama en formato hexadecimal
            hex_frame = ' '.join([f'{b:02X}' for b in frame])
            print(f"Trama: {hex_frame}")
        
        # Guardar todas las tramas en el archivo
        self._save_frames(all_frames, output_filename)
        
        print(f"\nArchivo de tramas guardado como: {output_filename}")
        print(f"Total de tramas generadas: {len(all_frames)}")

    def _save_frames(self, frames, output_filename):
        """
        Guarda las tramas en un archivo de texto con formato hexadecimal
        
        Args:
            frames (list): Lista de tramas en formato bytes
            output_filename (str): Nombre del archivo de salida
        """
        try:
            with open(output_filename, 'w', encoding='utf-8') as f:
                # Escribir encabezado del archivo
                f.write("# Archivo de tramas de bytes\n")
                f.write("# Formato: [STX][LEN][DATA][CRC][ETX]\n")
                f.write(f"# STX = 0x{self.STX:02X} (inicio de trama)\n")
                f.write(f"# ETX = 0x{self.ETX:02X} (fin de trama)\n")
                f.write(f"# Separador de campos = '{self.SEPARATOR}'\n")
                f.write("# CRC = Suma de bytes de datos módulo 256\n")
                f.write("\n")
                
                # Escribir cada trama
                for i, frame in enumerate(frames, 1):
                    # Convertir bytes a representación hexadecimal
                    hex_representation = ' '.join([f'{b:02X}' for b in frame])
                    
                    # Escribir número de trama y datos
                    f.write(f"# Trama {i}\n")
                    f.write(f"{hex_representation}\n\n")
                
                # Escribir estadísticas finales
                f.write(f"# Total de tramas: {len(frames)}\n")
                f.write(f"# Bytes totales: {sum(len(frame) for frame in frames)}\n")
                
        except IOError as e:
            raise IOError(f"Error al guardar el archivo de tramas: {e}")

    def verify_frame(self, frame_bytes):
        """
        Verifica la integridad de una trama
        
        Args:
            frame_bytes (bytes): Trama a verificar
            
        Returns:
            tuple: (is_valid, error_message)
        """
        # Verificar longitud mínima
        if len(frame_bytes) < 4:
            return False, "Trama demasiado corta"
        
        # Verificar STX y ETX
        if frame_bytes[0] != self.STX:
            return False, f"STX incorrecto"
        
        if frame_bytes[-1] != self.ETX:
            return False, f"ETX incorrecto"
        
        # Verificar longitud
        declared_length = frame_bytes[1]
        actual_data_length = len(frame_bytes) - 4
        
        if declared_length != actual_data_length:
            return False, f"Longitud incorrecta"
        
        # Verificar checksum
        data_bytes = frame_bytes[2:-2]
        calculated_checksum = sum(data_bytes) % 256
        declared_checksum = frame_bytes[-2]
        
        if calculated_checksum != declared_checksum:
            return False, f"Checksum incorrecto"
        
        return True, "Trama válida"


# Uso desde línea de comandos
if __name__ == "__main__":
    print("=" * 60)
    print("CONVERTIDOR CSV A TRAMAS DE BYTES")
    print("=" * 60)
    
    if len(sys.argv) > 1:
        csv_file = sys.argv[1]
        frame_file = csv_file.replace('.csv', '.dat')
        
        converter = FrameConverter()
        converter.read_csv_and_convert(csv_file, frame_file)
    else:
        print("\nUSO:")
        print("  python frame_converter.py archivo.csv")
        print("\nEJEMPLOS:")
        print("  python frame_converter.py datos.csv")
        print("  python frame_converter.py estudiantes.csv")
        print("\nFORMATO DE TRAMA:")
        print("  [STX] [LEN] [DATA] [CRC] [ETX]")
        print("  • STX = 0x02 (inicio)")
        print("  • LEN = Longitud de datos")
        print("  • DATA = Campos separados por '|'")
        print("  • CRC = Suma de bytes módulo 256")
        print("  • ETX = 0x03 (fin)")
