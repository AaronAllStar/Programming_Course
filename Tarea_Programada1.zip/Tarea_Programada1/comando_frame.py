from frame_converter import FrameConverter

converter = FrameConverter()
converter.read_csv_and_convert('ejemplo.csv', 'ejemplo.dat')
