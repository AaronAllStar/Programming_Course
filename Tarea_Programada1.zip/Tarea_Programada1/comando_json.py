from json_converter1 import JSONConverter

converter = JSONConverter()
converter.read_csv_and_convert('ejemplo.csv', 'ejemplo.json')
