import sqlite3
from typing import List, Tuple, Optional


class DatabaseManager:
    """
    Gestor de base de datos SQLite para productos
    Implementa operaciones CRUD (Create, Read, Update, Delete)
    """

    def __init__(self, db_name: str = "productos.db"):
        """
        Inicializa la conexión a la base de datos

        Args:
            db_name: Nombre del archivo de base de datos
        """
        self.db_name = db_name
        self.connection = None
        self.cursor = None
        self._connect()
        self._create_table()

    def _connect(self):
        """Establece conexión con la base de datos"""
        try:
            self.connection = sqlite3.connect(self.db_name)
            self.cursor = self.connection.cursor()
        except sqlite3.Error as e:
            print(f"Error al conectar a la base de datos: {e}")
            raise

    def _create_table(self):
        """Crea la tabla de productos si no existe"""
        create_table_query = """
        CREATE TABLE IF NOT EXISTS productos (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            nombre TEXT NOT NULL,
            categoria TEXT NOT NULL,
            precio REAL NOT NULL,
            proveedor TEXT NOT NULL
        )
        """

        try:
            self.cursor.execute(create_table_query)
            self.connection.commit()
        except sqlite3.Error as e:
            print(f"Error al crear la tabla: {e}")
            raise

    def guardar_producto(self, nombre: str, categoria: str, precio: float, proveedor: str) -> bool:
        """
        Guarda un nuevo producto en la base de datos

        Args:
            nombre: Nombre del producto
            categoria: Categoría del producto
            precio: Precio del producto
            proveedor: Nombre del proveedor

        Returns:
            bool: True si se guardó correctamente, False en caso contrario
        """
        insert_query = """
        INSERT INTO productos (nombre, categoria, precio, proveedor)
        VALUES (?, ?, ?, ?)
        """

        try:
            self.cursor.execute(insert_query, (nombre, categoria, precio, proveedor))
            self.connection.commit()
            return True
        except sqlite3.Error as e:
            print(f"Error al guardar el producto: {e}")
            return False

    def listar_productos(self) -> List[Tuple]:
        """
        Lista todos los productos almacenados

        Returns:
            List[Tuple]: Lista de tuplas con los datos de los productos
        """
        select_query = "SELECT id, nombre, categoria, precio, proveedor FROM productos ORDER BY id"

        try:
            self.cursor.execute(select_query)
            return self.cursor.fetchall()
        except sqlite3.Error as e:
            print(f"Error al listar productos: {e}")
            return []

    def buscar_por_nombre(self, fragmento: str) -> List[Tuple]:
        """
        Busca productos por aproximación en el nombre

        Args:
            fragmento: Texto a buscar en el nombre del producto

        Returns:
            List[Tuple]: Lista de productos que coinciden
        """
        search_query = """
        SELECT id, nombre, categoria, precio, proveedor 
        FROM productos 
        WHERE nombre LIKE ?
        ORDER BY id
        """

        try:
            # Agregar % para búsqueda por aproximación
            pattern = f"%{fragmento}%"
            self.cursor.execute(search_query, (pattern,))
            return self.cursor.fetchall()
        except sqlite3.Error as e:
            print(f"Error al buscar productos: {e}")
            return []

    def buscar_por_rango_precio(self, precio_min: float, precio_max: float) -> List[Tuple]:
        """
        Busca productos por rango de precio

        Args:
            precio_min: Precio mínimo (inclusive)
            precio_max: Precio máximo (inclusive)

        Returns:
            List[Tuple]: Lista de productos en el rango de precio
        """
        search_query = """
        SELECT id, nombre, categoria, precio, proveedor 
        FROM productos 
        WHERE precio BETWEEN ? AND ?
        ORDER BY precio
        """

        try:
            self.cursor.execute(search_query, (precio_min, precio_max))
            return self.cursor.fetchall()
        except sqlite3.Error as e:
            print(f"Error al buscar por rango de precio: {e}")
            return []

    def modificar_producto(self, producto_id: int, nuevo_precio: float, nuevo_proveedor: str) -> bool:
        """
        Modifica el precio y proveedor de un producto

        Args:
            producto_id: ID del producto a modificar
            nuevo_precio: Nuevo precio del producto
            nuevo_proveedor: Nuevo nombre del proveedor

        Returns:
            bool: True si se modificó correctamente, False en caso contrario
        """
        update_query = """
        UPDATE productos 
        SET precio = ?, proveedor = ?
        WHERE id = ?
        """

        try:
            self.cursor.execute(update_query, (nuevo_precio, nuevo_proveedor, producto_id))
            self.connection.commit()

            # Verificar si se modificó alguna fila
            if self.cursor.rowcount > 0:
                return True
            else:
                print(f"No se encontró el producto con ID {producto_id}")
                return False
        except sqlite3.Error as e:
            print(f"Error al modificar el producto: {e}")
            return False

    def borrar_producto(self, producto_id: int) -> bool:
        """
        Borra un producto de la base de datos

        Args:
            producto_id: ID del producto a borrar

        Returns:
            bool: True si se borró correctamente, False en caso contrario
        """
        delete_query = "DELETE FROM productos WHERE id = ?"

        try:
            self.cursor.execute(delete_query, (producto_id,))
            self.connection.commit()

            # Verificar si se borró alguna fila
            if self.cursor.rowcount > 0:
                return True
            else:
                print(f"No se encontró el producto con ID {producto_id}")
                return False
        except sqlite3.Error as e:
            print(f"Error al borrar el producto: {e}")
            return False

    def obtener_producto_por_id(self, producto_id: int) -> Optional[Tuple]:
        """
        Obtiene un producto específico por su ID

        Args:
            producto_id: ID del producto

        Returns:
            Optional[Tuple]: Tupla con los datos del producto o None si no existe
        """
        select_query = "SELECT id, nombre, categoria, precio, proveedor FROM productos WHERE id = ?"

        try:
            self.cursor.execute(select_query, (producto_id,))
            return self.cursor.fetchone()
        except sqlite3.Error as e:
            print(f"Error al obtener el producto: {e}")
            return None

    def close(self):
        """Cierra la conexión a la base de datos"""
        if self.connection:
            self.connection.close()
