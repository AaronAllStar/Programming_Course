#!/usr/bin/env python3
"""
Script de prueba automática para el Sistema de Gestión de Productos
Demuestra todas las funcionalidades del sistema
"""

from database import DatabaseManager
import os


def test_sistema():
    """Ejecuta pruebas de todas las funcionalidades"""

    print("="*70)
    print("PRUEBAS AUTOMATIZADAS - SISTEMA DE GESTIÓN DE PRODUCTOS")
    print("="*70)

    # Crear base de datos de prueba
    db = DatabaseManager("test_productos.db")

    print("\n[TEST 1] Creación de base de datos y tabla...")
    print("✓ Base de datos creada exitosamente")

    # Test 1: Guardar productos
    print("\n[TEST 2] Guardar productos...")
    productos_prueba = [
        ("Laptop Dell XPS 15", "Electrónica", 1299.99, "Dell Inc."),
        ("Mouse Logitech MX Master", "Periféricos", 99.99, "Logitech"),
        ("Teclado Mecánico Corsair", "Periféricos", 149.99, "Corsair"),
        ("Monitor LG 27 4K", "Electrónica", 449.99, "LG Electronics"),
        ("Webcam Logitech C920", "Periféricos", 79.99, "Logitech"),
        ("Silla Ergonómica Herman Miller", "Mobiliario", 1200.00, "Herman Miller"),
        ("Escritorio Ajustable", "Mobiliario", 599.99, "IKEA"),
        ("Auriculares Sony WH-1000XM4", "Audio", 349.99, "Sony"),
        ("Micrófono Blue Yeti", "Audio", 129.99, "Blue Microphones"),
        ("Cable HDMI 2.1", "Accesorios", 24.99, "Amazon Basics")
    ]

    for nombre, categoria, precio, proveedor in productos_prueba:
        if db.guardar_producto(nombre, categoria, precio, proveedor):
            print(f"  ✓ Guardado: {nombre}")
        else:
            print(f"  ✗ Error al guardar: {nombre}")

    # Test 2: Listar productos
    print("\n[TEST 3] Listar todos los productos...")
    productos = db.listar_productos()
    print(f"  ✓ Total de productos: {len(productos)}")
    print("\n  " + "="*100)
    print(f"  {'ID':<6} {'NOMBRE':<30} {'CATEGORÍA':<15} {'PRECIO':<12} {'PROVEEDOR':<20}")
    print("  " + "-"*100)
    for prod in productos:
        print(f"  {prod[0]:<6} {prod[1]:<30} {prod[2]:<15} ${prod[3]:<11.2f} {prod[4]:<20}")
    print("  " + "="*100)

    # Test 3: Buscar por nombre
    print("\n[TEST 4] Buscar por nombre (aproximación): 'logitech'...")
    resultados = db.buscar_por_nombre("logitech")
    print(f"  ✓ Productos encontrados: {len(resultados)}")
    for prod in resultados:
        print(f"    - ID {prod[0]}: {prod[1]} (${prod[3]:.2f})")

    # Test 4: Buscar por rango de precio
    print("\n[TEST 5] Buscar por rango de precio: $50 - $150...")
    resultados = db.buscar_por_rango_precio(50.0, 150.0)
    print(f"  ✓ Productos encontrados: {len(resultados)}")
    for prod in resultados:
        print(f"    - ID {prod[0]}: {prod[1]} (${prod[3]:.2f})")

    # Test 5: Modificar producto
    print("\n[TEST 6] Modificar producto ID 1...")
    producto_original = db.obtener_producto_por_id(1)
    print(f"  Original: {producto_original[1]} - ${producto_original[3]:.2f} - {producto_original[4]}")

    if db.modificar_producto(1, 1199.99, "Dell Costa Rica"):
        producto_modificado = db.obtener_producto_por_id(1)
        print(f"  ✓ Modificado: {producto_modificado[1]} - ${producto_modificado[3]:.2f} - {producto_modificado[4]}")
    else:
        print("  ✗ Error al modificar producto")

    # Test 6: Intentar modificar producto inexistente
    print("\n[TEST 7] Intentar modificar producto inexistente (ID 999)...")
    if not db.modificar_producto(999, 99.99, "Test"):
        print("  ✓ Correctamente detectado producto inexistente")
    else:
        print("  ✗ Error: debería fallar")

    # Test 7: Borrar producto
    print("\n[TEST 8] Borrar producto ID 10...")
    producto_a_borrar = db.obtener_producto_por_id(10)
    print(f"  Producto a borrar: {producto_a_borrar[1]}")

    if db.borrar_producto(10):
        print("  ✓ Producto borrado exitosamente")
        # Verificar que ya no existe
        if db.obtener_producto_por_id(10) is None:
            print("  ✓ Verificado: producto no existe en la base de datos")
    else:
        print("  ✗ Error al borrar producto")

    # Test 8: Verificar integridad después de borrado
    print("\n[TEST 9] Verificar integridad de la base de datos...")
    productos_final = db.listar_productos()
    print(f"  ✓ Total de productos después del borrado: {len(productos_final)}")

    # Test 9: Buscar producto borrado
    print("\n[TEST 10] Buscar producto borrado (ID 10)...")
    producto_borrado = db.obtener_producto_por_id(10)
    if producto_borrado is None:
        print("  ✓ Correctamente retorna None para producto inexistente")
    else:
        print("  ✗ Error: el producto debería estar borrado")

    # Test 10: Búsqueda sin resultados
    print("\n[TEST 11] Buscar por nombre sin resultados: 'XYZ123'...")
    resultados = db.buscar_por_nombre("XYZ123")
    if len(resultados) == 0:
        print("  ✓ Correctamente retorna lista vacía")
    else:
        print("  ✗ Error: debería retornar lista vacía")

    # Cerrar conexión
    db.close()
    print("\n[TEST 12] Cerrar conexión a base de datos...")
    print("  ✓ Conexión cerrada correctamente")

    # Resumen
    print("\n" + "="*70)
    print("RESUMEN DE PRUEBAS")
    print("="*70)
    print("✓ Todas las pruebas completadas exitosamente")
    print("✓ Sistema funcionando correctamente")
    print("="*70)

    # Limpiar base de datos de prueba
    if os.path.exists("test_productos.db"):
        os.remove("test_productos.db")
        print("\n✓ Base de datos de prueba eliminada")


if __name__ == "__main__":
    try:
        test_sistema()
    except Exception as e:
        print(f"\n✗ Error durante las pruebas: {str(e)}")
        import traceback
        traceback.print_exc()
