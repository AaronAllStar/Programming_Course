#!/usr/bin/env python3
"""
Prueba simple para verificar que database.py funciona
"""

# Importar el módulo database
from database import DatabaseManager

# Crear instancia de la base de datos
print("Creando conexión a base de datos...")
db = DatabaseManager("test.db")
print("✓ Conexión exitosa")

# Guardar un producto de prueba
print("\nGuardando producto de prueba...")
resultado = db.guardar_producto(
    nombre="Laptop Test",
    categoria="Electrónica",
    precio=999.99,
    proveedor="Test Inc."
)

if resultado:
    print("✓ Producto guardado exitosamente")
else:
    print("✗ Error al guardar producto")

# Listar productos
print("\nListando productos...")
productos = db.listar_productos()
print(f"✓ Total de productos: {len(productos)}")

for prod in productos:
    print(f"  ID {prod[0]}: {prod[1]} - ${prod[3]:.2f}")

# Cerrar conexión
db.close()
print("\n✓ Prueba completada exitosamente")
print("✓ La base de datos funciona correctamente")
