import sys
from typing import Optional


class InterfazUsuario:
    """
    Interfaz de usuario para el sistema CRUD de productos
    """

    def __init__(self):
        """Inicializa la interfaz de usuario"""
        self.menu_principal = """
╔═══════════════════════════════════════════════════════════╗
║         SISTEMA DE GESTIÓN DE PRODUCTOS - CRUD            ║
╚═══════════════════════════════════════════════════════════╝

[1] Guardar nuevo producto
[2] Listar todos los productos
[3] Buscar productos
[4] Modificar producto
[5] Borrar producto
[6] Salir

Seleccione una opción: """

        self.menu_buscar = """
╔═══════════════════════════════════════════════════════════╗
║                    BUSCAR PRODUCTOS                       ║
╚═══════════════════════════════════════════════════════════╝

[1] Buscar por nombre (aproximación)
[2] Buscar por rango de precio
[3] Volver al menú principal

Seleccione una opción: """

    def mostrar_menu_principal(self):
        """Muestra el menú principal y obtiene la opción del usuario"""
        print("\n" * 2)
        opcion = input(self.menu_principal).strip()
        return opcion

    def mostrar_menu_buscar(self):
        """Muestra el menú de búsqueda y obtiene la opción del usuario"""
        print("\n" * 2)
        opcion = input(self.menu_buscar).strip()
        return opcion

    def solicitar_datos_producto(self):
        """Solicita al usuario los datos de un nuevo producto"""
        print("\n" + "="*60)
        print("          GUARDAR NUEVO PRODUCTO")
        print("="*60 + "\n")

        nombre = input("Nombre del producto: ").strip()
        categoria = input("Categoría: ").strip()

        # Validar precio
        while True:
            try:
                precio_str = input("Precio: $").strip()
                precio = float(precio_str)
                if precio < 0:
                    print("El precio no puede ser negativo. Intente de nuevo.")
                    continue
                break
            except ValueError:
                print("Precio inválido. Debe ser un número. Intente de nuevo.")

        proveedor = input("Nombre del proveedor: ").strip()

        return {
            "nombre": nombre,
            "categoria": categoria,
            "precio": precio,
            "proveedor": proveedor
        }

    def mostrar_productos(self, productos, titulo="LISTA DE PRODUCTOS"):
        """Muestra una lista de productos en formato tabla"""
        print("\n" + "="*100)
        print(f"{titulo:^100}")
        print("="*100)

        if not productos:
            print("\nNo se encontraron productos.\n")
            return

        # Encabezados
        print(f"{'ID':<6} {'NOMBRE':<25} {'CATEGORÍA':<20} {'PRECIO':<12} {'PROVEEDOR':<25}")
        print("-"*100)

        # Datos
        for producto in productos:
            id_prod, nombre, categoria, precio, proveedor = producto
            print(f"{id_prod:<6} {nombre:<25} {categoria:<20} ${precio:<11.2f} {proveedor:<25}")

        print("="*100)
        print(f"\nTotal de productos: {len(productos)}\n")

    def solicitar_fragmento_nombre(self):
        """Solicita al usuario un fragmento de nombre para búsqueda"""
        print("\n" + "="*60)
        print("      BUSCAR POR NOMBRE (APROXIMACIÓN)")
        print("="*60 + "\n")
        fragmento = input("Ingrese el nombre o parte del nombre: ").strip()
        return fragmento

    def solicitar_rango_precio(self):
        """Solicita al usuario un rango de precios para búsqueda"""
        print("\n" + "="*60)
        print("         BUSCAR POR RANGO DE PRECIO")
        print("="*60 + "\n")

        while True:
            try:
                precio_min = float(input("Precio mínimo: $").strip())
                precio_max = float(input("Precio máximo: $").strip())

                if precio_min < 0 or precio_max < 0:
                    print("Los precios no pueden ser negativos. Intente de nuevo.\n")
                    continue

                if precio_min > precio_max:
                    print("El precio mínimo no puede ser mayor al precio máximo. Intente de nuevo.\n")
                    continue

                return precio_min, precio_max
            except ValueError:
                print("Precios inválidos. Deben ser números. Intente de nuevo.\n")

    def solicitar_id_producto(self, accion="modificar"):
        """Solicita al usuario el ID de un producto"""
        print("\n" + "="*60)
        print(f"         {accion.upper()} PRODUCTO")
        print("="*60 + "\n")

        while True:
            try:
                producto_id = int(input("Ingrese el ID del producto: ").strip())
                if producto_id < 1:
                    print("El ID debe ser un número positivo. Intente de nuevo.\n")
                    continue
                return producto_id
            except ValueError:
                print("ID inválido. Debe ser un número entero. Intente de nuevo.\n")

    def solicitar_datos_modificacion(self):
        """Solicita al usuario los nuevos datos para modificar un producto"""
        print("\nIngrese los nuevos datos:\n")

        while True:
            try:
                nuevo_precio = float(input("Nuevo precio: $").strip())
                if nuevo_precio < 0:
                    print("El precio no puede ser negativo. Intente de nuevo.")
                    continue
                break
            except ValueError:
                print("Precio inválido. Debe ser un número. Intente de nuevo.")

        nuevo_proveedor = input("Nuevo proveedor: ").strip()

        return {
            "precio": nuevo_precio,
            "proveedor": nuevo_proveedor
        }

    def confirmar_accion(self, mensaje):
        """Solicita confirmación al usuario para una acción"""
        respuesta = input(f"\n{mensaje} (s/n): ").strip().lower()
        return respuesta in ["s", "si", "sí", "yes", "y"]

    def mostrar_mensaje_exito(self, mensaje):
        """Muestra un mensaje de éxito"""
        print(f"\n✓ {mensaje}\n")

    def mostrar_mensaje_error(self, mensaje):
        """Muestra un mensaje de error"""
        print(f"\n✗ {mensaje}\n")

    def mostrar_mensaje_info(self, mensaje):
        """Muestra un mensaje informativo"""
        print(f"\nℹ️  {mensaje}\n")

    def pausar(self):
        """Pausa la ejecución hasta que el usuario presione Enter"""
        input("\nPresione Enter para continuar...")

    def despedida(self):
        """Muestra mensaje de despedida"""
        print("\n" + "="*60)
        print("     Gracias por usar el Sistema de Gestión de Productos")
        print("              Universidad Lead - Tarea Programada 3")
        print("="*60 + "\n")
