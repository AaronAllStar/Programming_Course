#!/usr/bin/env python3
"""
Sistema de Gestión de Productos - CRUD
Tarea Programada 3 - Universidad Lead
Profesor: Mario Agüero

Sistema que implementa operaciones CRUD (Create, Read, Update, Delete)
usando SQLite3 de la biblioteca estándar de Python
"""

import sys
from database import DatabaseManager
from ui import InterfazUsuario


class SistemaGestionProductos:
    """
    Controlador principal del sistema de gestión de productos
    """

    def __init__(self):
        """Inicializa el sistema"""
        self.db = DatabaseManager()
        self.ui = InterfazUsuario()
        self.ejecutando = True

    def ejecutar(self):
        """Ejecuta el bucle principal del sistema"""
        while self.ejecutando:
            opcion = self.ui.mostrar_menu_principal()

            if opcion == "1":
                self.guardar_producto()
            elif opcion == "2":
                self.listar_productos()
            elif opcion == "3":
                self.menu_buscar()
            elif opcion == "4":
                self.modificar_producto()
            elif opcion == "5":
                self.borrar_producto()
            elif opcion == "6":
                self.salir()
            else:
                self.ui.mostrar_mensaje_error("Opción inválida. Intente de nuevo.")
                self.ui.pausar()

    def guardar_producto(self):
        """Guarda un nuevo producto en la base de datos"""
        try:
            datos = self.ui.solicitar_datos_producto()

            # Validar que no haya campos vacíos
            if not datos["nombre"] or not datos["categoria"] or not datos["proveedor"]:
                self.ui.mostrar_mensaje_error("Todos los campos son obligatorios.")
                self.ui.pausar()
                return

            # Guardar en la base de datos
            if self.db.guardar_producto(
                datos["nombre"],
                datos["categoria"],
                datos["precio"],
                datos["proveedor"]
            ):
                self.ui.mostrar_mensaje_exito("Producto guardado correctamente.")
            else:
                self.ui.mostrar_mensaje_error("No se pudo guardar el producto.")

            self.ui.pausar()
        except Exception as e:
            self.ui.mostrar_mensaje_error(f"Error al guardar el producto: {str(e)}")
            self.ui.pausar()

    def listar_productos(self):
        """Lista todos los productos almacenados"""
        try:
            productos = self.db.listar_productos()
            self.ui.mostrar_productos(productos)
            self.ui.pausar()
        except Exception as e:
            self.ui.mostrar_mensaje_error(f"Error al listar productos: {str(e)}")
            self.ui.pausar()

    def menu_buscar(self):
        """Muestra el menú de búsqueda de productos"""
        while True:
            opcion = self.ui.mostrar_menu_buscar()

            if opcion == "1":
                self.buscar_por_nombre()
                break
            elif opcion == "2":
                self.buscar_por_rango_precio()
                break
            elif opcion == "3":
                break
            else:
                self.ui.mostrar_mensaje_error("Opción inválida. Intente de nuevo.")
                self.ui.pausar()

    def buscar_por_nombre(self):
        """Busca productos por aproximación en el nombre"""
        try:
            fragmento = self.ui.solicitar_fragmento_nombre()

            if not fragmento:
                self.ui.mostrar_mensaje_error("Debe ingresar al menos un carácter para buscar.")
                self.ui.pausar()
                return

            productos = self.db.buscar_por_nombre(fragmento)
            self.ui.mostrar_productos(productos, f"RESULTADOS BÚSQUEDA: '{fragmento}'")
            self.ui.pausar()
        except Exception as e:
            self.ui.mostrar_mensaje_error(f"Error al buscar productos: {str(e)}")
            self.ui.pausar()

    def buscar_por_rango_precio(self):
        """Busca productos por rango de precio"""
        try:
            precio_min, precio_max = self.ui.solicitar_rango_precio()
            productos = self.db.buscar_por_rango_precio(precio_min, precio_max)
            self.ui.mostrar_productos(
                productos,
                f"RESULTADOS BÚSQUEDA: ${precio_min:.2f} - ${precio_max:.2f}"
            )
            self.ui.pausar()
        except Exception as e:
            self.ui.mostrar_mensaje_error(f"Error al buscar productos: {str(e)}")
            self.ui.pausar()

    def modificar_producto(self):
        """Modifica los datos de un producto existente"""
        try:
            producto_id = self.ui.solicitar_id_producto("modificar")

            # Verificar que el producto existe
            producto = self.db.obtener_producto_por_id(producto_id)
            if not producto:
                self.ui.mostrar_mensaje_error(f"No existe un producto con ID {producto_id}.")
                self.ui.pausar()
                return

            # Mostrar datos actuales
            self.ui.mostrar_mensaje_info("Datos actuales del producto:")
            self.ui.mostrar_productos([producto])

            # Solicitar nuevos datos
            nuevos_datos = self.ui.solicitar_datos_modificacion()

            # Confirmar modificación
            if self.ui.confirmar_accion("¿Confirma que desea modificar este producto?"):
                if self.db.modificar_producto(
                    producto_id,
                    nuevos_datos["precio"],
                    nuevos_datos["proveedor"]
                ):
                    self.ui.mostrar_mensaje_exito("Producto modificado correctamente.")

                    # Mostrar producto modificado
                    producto_modificado = self.db.obtener_producto_por_id(producto_id)
                    self.ui.mostrar_mensaje_info("Datos actualizados:")
                    self.ui.mostrar_productos([producto_modificado])
                else:
                    self.ui.mostrar_mensaje_error("No se pudo modificar el producto.")
            else:
                self.ui.mostrar_mensaje_info("Modificación cancelada.")

            self.ui.pausar()
        except Exception as e:
            self.ui.mostrar_mensaje_error(f"Error al modificar el producto: {str(e)}")
            self.ui.pausar()

    def borrar_producto(self):
        """Borra un producto de la base de datos"""
        try:
            producto_id = self.ui.solicitar_id_producto("borrar")

            # Verificar que el producto existe
            producto = self.db.obtener_producto_por_id(producto_id)
            if not producto:
                self.ui.mostrar_mensaje_error(f"No existe un producto con ID {producto_id}.")
                self.ui.pausar()
                return

            # Mostrar producto a borrar
            self.ui.mostrar_mensaje_info("Producto a borrar:")
            self.ui.mostrar_productos([producto])

            # Confirmar borrado
            if self.ui.confirmar_accion("¿Está seguro que desea borrar este producto? Esta acción no se puede deshacer."):
                if self.db.borrar_producto(producto_id):
                    self.ui.mostrar_mensaje_exito("Producto borrado correctamente.")
                else:
                    self.ui.mostrar_mensaje_error("No se pudo borrar el producto.")
            else:
                self.ui.mostrar_mensaje_info("Borrado cancelado.")

            self.ui.pausar()
        except Exception as e:
            self.ui.mostrar_mensaje_error(f"Error al borrar el producto: {str(e)}")
            self.ui.pausar()

    def salir(self):
        """Sale del sistema"""
        if self.ui.confirmar_accion("¿Está seguro que desea salir?"):
            self.ui.despedida()
            self.db.close()
            self.ejecutando = False
        else:
            self.ui.mostrar_mensaje_info("Operación cancelada. Continuando...")
            self.ui.pausar()


def main():
    """Función principal que inicia el sistema"""
    try:
        sistema = SistemaGestionProductos()
        sistema.ejecutar()
    except KeyboardInterrupt:
        print("\n\nPrograma interrumpido por el usuario.")
        sys.exit(0)
    except Exception as e:
        print(f"\nError fatal: {str(e)}")
        sys.exit(1)


if __name__ == "__main__":
    main()
